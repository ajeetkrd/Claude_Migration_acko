<#
.SYNOPSIS
    Provision the Claude Desktop (3P) bootstrap config for the current user and
    make it the applied configuration. Pure PowerShell — no Python needed.

.DESCRIPTION
    Writes a <guid>.json bootstrap loader into the per-user configLibrary and
    creates/updates _meta.json so the config is listed AND applied.

    * Idempotent: re-running reuses an existing config whose bootstrapUrl matches
      instead of creating duplicates.
    * Non-destructive: other saved configurations in _meta.json are preserved.
    * Works on Windows PowerShell 5.1 and PowerShell 7+ (Windows/macOS/Linux).

    Quit Claude Desktop before running (config is read at launch). Use
    -ForceQuit to stop it automatically. The app must relaunch to apply, and the
    user approves the one-time "Apply settings from your organization?" dialog.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Configure-Bootstrap.ps1 -ForceQuit

.EXAMPLE
    .\Configure-Bootstrap.ps1 -Name "Eng Bootstrap" -Url "https://.../default.json" -DryRun
#>
[CmdletBinding()]
param(
    [string]   $Name        = "Org Bootstrap",
    [string]   $Url         = "https://raw.githubusercontent.com/ajeetkrd/bedrock-model-usage-claude/main/default.json",
    [hashtable]$Headers      = @{ "X-Config" = "ajeet" },
    [switch]   $NoHeader,
    [switch]   $NoApply,
    [switch]   $ForceQuit,
    [int]      $QuitTimeout  = 10,
    [switch]   $DryRun
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Process name of Claude Desktop (image "Claude.exe" -> process "Claude").
$ClaudeProcName = 'Claude'

function Test-OnWindows {
    if ($PSVersionTable.PSVersion.Major -lt 6) { return $true }  # Windows PowerShell 5.1
    return [bool]$IsWindows
}

function Get-ConfigLibraryDir {
    if (Test-OnWindows) {
        $base = $env:LOCALAPPDATA
        if (-not $base) { $base = Join-Path $HOME 'AppData\Local' }
        return Join-Path $base 'Claude-3p\configLibrary'
    }
    if ($PSVersionTable.PSVersion.Major -ge 6 -and $IsMacOS) {
        return Join-Path $HOME 'Library/Application Support/Claude-3p/configLibrary'
    }
    $base = $env:XDG_CONFIG_HOME
    if (-not $base) { $base = Join-Path $HOME '.config' }
    return Join-Path $base 'Claude-3p/configLibrary'
}

function Test-ClaudeRunning {
    try { return [bool](Get-Process -Name $ClaudeProcName -ErrorAction SilentlyContinue) }
    catch { return $false }
}

function Stop-Claude([int]$TimeoutSec) {
    if (-not (Test-ClaudeRunning)) { Write-Host "Claude Desktop: not running."; return $true }

    Write-Host "Claude Desktop: requesting graceful quit..."
    try {
        foreach ($p in (Get-Process -Name $ClaudeProcName -ErrorAction SilentlyContinue)) {
            $null = $p.CloseMainWindow()
        }
    } catch { }

    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        if (-not (Test-ClaudeRunning)) { Write-Host "Claude Desktop: exited cleanly."; return $true }
        Start-Sleep -Milliseconds 500
    }

    Write-Host "Claude Desktop: still running after timeout; forcing stop..."
    try { Get-Process -Name $ClaudeProcName -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue } catch { }
    Start-Sleep -Seconds 1

    if (Test-ClaudeRunning) { Write-Warning "Claude Desktop still appears to be running. Close it manually."; return $false }
    Write-Host "Claude Desktop: force-stopped."
    return $true
}

# JSON-escape a string via the serializer (returns a quoted "..." literal).
function ConvertTo-JsonString([string]$Value) { return ($Value | ConvertTo-Json) }

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)   # no BOM
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

# ---- Resolve paths & load existing meta ------------------------------------
$dir      = Get-ConfigLibraryDir
$metaPath = Join-Path $dir '_meta.json'

$entries   = New-Object System.Collections.ArrayList
$appliedId = $null

if (Test-Path $metaPath) {
    try { $meta = Get-Content -Raw -Path $metaPath | ConvertFrom-Json }
    catch { throw "Could not parse existing $metaPath : $_" }

    if ($meta.PSObject.Properties.Name -contains 'appliedId') { $appliedId = $meta.appliedId }
    if ($meta.PSObject.Properties.Name -contains 'entries' -and $meta.entries) {
        foreach ($e in $meta.entries) {
            [void]$entries.Add([pscustomobject]@{ id = $e.id; name = $e.name })
        }
    }
}

# ---- Build bootstrap config body -------------------------------------------
$body = [ordered]@{ bootstrapEnabled = $true; bootstrapUrl = $Url }
if (-not $NoHeader -and $Headers -and $Headers.Count -gt 0) { $body.bootstrapHeaders = $Headers }

# ---- Idempotency: find an existing config with the same bootstrapUrl --------
$existingId = $null
foreach ($e in $entries) {
    $f = Join-Path $dir ("{0}.json" -f $e.id)
    if (Test-Path $f) {
        try { $c = Get-Content -Raw -Path $f | ConvertFrom-Json } catch { continue }
        if ($c.PSObject.Properties.Name -contains 'bootstrapUrl' -and $c.bootstrapUrl -eq $Url) {
            $existingId = $e.id; break
        }
    }
}
$cfgId   = if ($existingId) { $existingId } else { [guid]::NewGuid().ToString() }
$cfgFile = Join-Path $dir ("{0}.json" -f $cfgId)
$action  = if ($existingId) { "UPDATE existing" } else { "CREATE new" }

Write-Host "configLibrary : $dir"
Write-Host "config id     : $cfgId  ($action)"
Write-Host "name          : $Name"
Write-Host "bootstrapUrl  : $Url"
Write-Host ("headers       : " + $(if ($body.Contains('bootstrapHeaders')) { ($Headers.Keys -join ', ') } else { '(none)' }))
Write-Host ("apply as active: " + (-not $NoApply))

$bodyJson = ($body | ConvertTo-Json -Depth 10)

if ($DryRun) {
    Write-Host "`n-DryRun: no files written."
    if ($ForceQuit) { Write-Host "Would quit Claude Desktop before writing." }
    Write-Host "Would write config:`n$bodyJson"
    return
}

# ---- Ensure the app is not running -----------------------------------------
if ($ForceQuit) {
    if (-not (Stop-Claude -TimeoutSec $QuitTimeout)) {
        Write-Error "Could not stop Claude Desktop; aborting to avoid a lost write."
        exit 1
    }
} elseif (Test-ClaudeRunning) {
    Write-Error "Claude Desktop is running. Quit it first, or re-run with -ForceQuit."
    exit 1
}

# ---- Write config file ------------------------------------------------------
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Write-Utf8NoBom -Path $cfgFile -Text ($bodyJson + "`n")

# ---- Update entry list (add or rename) -------------------------------------
$found = $false
foreach ($e in $entries) { if ($e.id -eq $cfgId) { $e.name = $Name; $found = $true } }
if (-not $found) { [void]$entries.Add([pscustomobject]@{ id = $cfgId; name = $Name }) }

if (-not $NoApply) { $appliedId = $cfgId }

# ---- Hand-build _meta.json so `entries` is ALWAYS a JSON array --------------
# (ConvertTo-Json collapses a single-element array to an object on PS 5.1.)
$entryLines = foreach ($e in $entries) {
    '    { "id": ' + (ConvertTo-JsonString $e.id) + ', "name": ' + (ConvertTo-JsonString $e.name) + ' }'
}
$entriesBlock = "[`n" + ($entryLines -join ",`n") + "`n  ]"

$metaJson = "{`n"
if ($appliedId) { $metaJson += '  "appliedId": ' + (ConvertTo-JsonString $appliedId) + ",`n" }
$metaJson += '  "entries": ' + $entriesBlock + "`n}`n"

Write-Utf8NoBom -Path $metaPath -Text $metaJson

$stamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ssZ")
Write-Host "`nDone ($stamp)."
Write-Host "Reopen Claude Desktop and approve the org-settings dialog if shown."
