@echo off
REM Double-clickable Windows launcher for configure_bootstrap.py.
REM Runs the Python configurator with --force-quit, then pauses.
REM Distribute alongside configure_bootstrap.py (same folder).

setlocal
set "DIR=%~dp0"
set "SCRIPT=%DIR%configure_bootstrap.py"

if not exist "%SCRIPT%" (
  echo ERROR: configure_bootstrap.py not found next to this launcher.
  pause
  exit /b 1
)

REM Prefer the py launcher, then python on PATH.
set "PY="
where py >nul 2>&1 && set "PY=py"
if not defined PY (
  where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo ERROR: Python 3 not found. Install it from python.org (tick "Add to PATH") and retry.
  pause
  exit /b 1
)

echo Configuring Claude Desktop bootstrap...
"%PY%" "%SCRIPT%" --force-quit %*
set "code=%ERRORLEVEL%"

echo.
if "%code%"=="0" (
  echo Success. Reopen Claude Desktop and approve the org-settings dialog if shown.
) else (
  echo Finished with errors ^(exit %code%^). See messages above.
)
pause
exit /b %code%
