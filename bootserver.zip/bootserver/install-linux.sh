#!/bin/bash
# Linux launcher for configure_bootstrap.py (login script or manual run).
# Runs the Python configurator with --force-quit. No pause (suits automation);
# add `read -r -p "..."` at the end if you want an interactive pause.
# Distribute alongside configure_bootstrap.py (same folder).

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$DIR/configure_bootstrap.py"

if [ ! -f "$SCRIPT" ]; then
  echo "ERROR: configure_bootstrap.py not found next to this launcher." >&2
  exit 1
fi

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "ERROR: Python 3 not found on PATH." >&2
  exit 1
fi

echo "Configuring Claude Desktop bootstrap..."
exec "$PY" "$SCRIPT" --force-quit "$@"
