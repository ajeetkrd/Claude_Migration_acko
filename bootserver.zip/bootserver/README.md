# Claude Desktop (3P) — Bootstrap Configuration & Fleet Rollout

This package configures **Claude Desktop in third‑party (3P) mode** to pull its
settings from a central **bootstrap URL**, and distributes that configuration to
a team of machines across macOS, Windows, and Linux.

Every machine points at one JSON file (`default.json`) hosted at an HTTPS URL.
When Claude Desktop launches it fetches that file, applies the settings, and
marks them read‑only. Change the hosted file once → every machine picks it up on
its next relaunch.

---

## Contents

| File | Purpose |
|------|---------|
| `default.json` | The **bootstrap overlay** — the actual Claude 3P config (provider, models, token limits, etc.). Host this at an HTTPS URL. |
| `configure_bootstrap.py` | Cross‑platform Python configurator. Writes the local bootstrap loader + `_meta.json`. |
| `install-macos.command` | Double‑clickable macOS launcher for the Python script. |
| `install-windows.bat` | Double‑clickable Windows launcher for the Python script. |
| `install-linux.sh` | Linux launcher (login‑script friendly). |
| `Configure-Bootstrap.ps1` | Pure‑PowerShell configurator (no Python needed) — best for Windows fleets. |
| `bootstrap-server/` | *Optional / advanced* — Pattern B: a Lambda that returns a different config per user group (see the last section). |

---

## How it works

Claude Desktop is a single app; "3P mode" is a launch mode it enters when it
finds a valid 3P configuration. The configuration can come from three sources
(highest precedence first):

1. **MDM / managed profile** (enforced, read‑only)
2. **Bootstrap URL** (fetched at launch; values become read‑only)
3. **Local `configLibrary` file** (lowest precedence, user‑editable)

Because we do **not** require MDM, we put the bootstrap *pointer* (a tiny
`bootstrapUrl` + `bootstrapHeaders` config) into the local `configLibrary`, and
everything real is served from the hosted `default.json`.

> **Note:** Without MDM the config is *centralized* but **not enforced** — a user
> with access to their own machine can edit the local file. If a setting is a
> compliance control, use MDM instead of this local‑file method.

### Per‑OS config location

| OS | `configLibrary` path |
|----|----------------------|
| macOS | `~/Library/Application Support/Claude-3p/configLibrary/` |
| Windows | `%LOCALAPPDATA%\Claude-3p\configLibrary\` |
| Linux | `~/.config/Claude-3p/configLibrary/` |

The configurator writes two things there: a `<uuid>.json` bootstrap loader and a
`_meta.json` index that lists and applies it.

---

## Step 1 — Host the bootstrap overlay

1. Put `default.json` in a repository, e.g. GitHub.
2. Use the **raw** HTTPS URL (not the `github.com/.../blob/...` page URL, which
   returns HTML and will fail to parse):

   ```
   https://raw.githubusercontent.com/<owner>/<repo>/main/default.json
   ```

3. The repo must be **public** for anonymous fetch. (For a private repo, use
   `bootstrapHeaders` with a token — see Troubleshooting.)
4. Verify it returns raw JSON:

   ```bash
   curl -s https://raw.githubusercontent.com/<owner>/<repo>/main/default.json | head
   ```

   You should see `{ … }` only — no web‑page chrome.

> **Sensitive data:** a public file exposes whatever is inside it (AWS account
> ID, SSO URL, inference‑profile ARNs). None are secrets, but if you'd rather not
> publish them, use a private repo + token, or GitHub Pages behind auth.

---

## Step 2 — Configure each machine

All three OSes end up writing the same tiny loader into `configLibrary`:

```json
{
  "bootstrapEnabled": true,
  "bootstrapUrl": "https://raw.githubusercontent.com/<owner>/<repo>/main/default.json",
  "bootstrapHeaders": { "X-Config": "team" }
}
```

The `bootstrapHeaders` line is **required for a no‑auth public URL** — any static
header flips the app out of "device‑code OAuth" mode (otherwise it probes the
URL's origin for an OAuth server and fails with a `.well-known/oauth-authorization-server`
404). GitHub simply ignores the header.

Pick the method for each OS below. **Quit Claude Desktop first** (or let the
`--force-quit` / `-ForceQuit` flag do it) — config is only read at launch.

### macOS

**Option A — double‑click launcher**

1. Copy `configure_bootstrap.py` and `install-macos.command` into the same folder.
2. Ensure the launcher is executable (a download can strip this):
   ```bash
   chmod +x install-macos.command
   ```
3. Double‑click `install-macos.command` (first run may need right‑click → Open to
   clear Gatekeeper quarantine), or run it in Terminal.

**Option B — command line / MDM script**

```bash
python3 configure_bootstrap.py --force-quit \
  --url "https://raw.githubusercontent.com/<owner>/<repo>/main/default.json" \
  --header "X-Config=team"
```

### Windows

**Option A — PowerShell (recommended, no Python needed)**

```powershell
powershell -ExecutionPolicy Bypass -File .\Configure-Bootstrap.ps1 -ForceQuit `
  -Url "https://raw.githubusercontent.com/<owner>/<repo>/main/default.json"
```

**Option B — double‑click launcher (requires Python)**

1. Copy `configure_bootstrap.py` and `install-windows.bat` into the same folder.
2. Double‑click `install-windows.bat`.

> The Windows executable name is assumed to be **`Claude.exe`**. Confirm in Task
> Manager → Details; if different, update `WINDOWS_IMAGE` in the Python script or
> `$ClaudeProcName` in the PowerShell script.

### Linux

```bash
chmod +x install-linux.sh
./install-linux.sh --url "https://raw.githubusercontent.com/<owner>/<repo>/main/default.json"
```

or directly:

```bash
python3 configure_bootstrap.py --force-quit \
  --url "https://raw.githubusercontent.com/<owner>/<repo>/main/default.json"
```

---

## Step 3 — Relaunch & verify

1. Reopen Claude Desktop.
2. Approve the one‑time **"Apply settings from your organization?"** dialog if it
   appears (it lists the sign‑in target and endpoints the overlay delivers).
3. At the login screen, choose your deployment (e.g. **"via Bedrock"**) and sign
   in.
4. Open the configuration window — settings delivered by the overlay show as
   **read‑only / organization‑managed**. That confirms the bootstrap applied.
5. If something looks off, check **Help → Troubleshooting** (the diagnostic
   report lists any dropped or invalid keys).

---

## Command reference

Both configurators accept the same options.

**Python (`configure_bootstrap.py`)**

| Flag | Meaning |
|------|---------|
| `--url URL` | Bootstrap config URL. |
| `--name NAME` | Display name for the saved configuration. |
| `--header Name=Value` | Static bootstrap header (repeatable). Default `X-Config=ajeet`. |
| `--no-header` | Send no headers (only if the URL needs no auth‑mode nudge). |
| `--no-apply` | Write the config but don't make it active. |
| `--force-quit` | Quit Claude Desktop (graceful, then force) before writing. |
| `--quit-timeout N` | Seconds to wait for graceful quit (default 10). |
| `--dry-run` | Show actions without writing files. |

**PowerShell (`Configure-Bootstrap.ps1`)**

`-Url`, `-Name`, `-Headers @{ "X-Config"="team" }`, `-NoHeader`, `-NoApply`,
`-ForceQuit`, `-QuitTimeout N`, `-DryRun`.

Both scripts are **idempotent** (re‑running updates the existing config with a
matching URL instead of creating duplicates) and **non‑destructive** (other saved
configurations in `_meta.json` are preserved).

---

## Updating the configuration later

1. Edit the hosted `default.json` and commit/push.
2. Allow ~5 minutes for the CDN cache (GitHub `raw` has a short TTL).
3. On each machine: Claude re‑fetches on its next background check, shows a
   relaunch prompt, and applies the change on relaunch. A **full quit + reopen**
   always pulls the latest immediately.

You never need to re‑run the configurator to change settings — only to change the
`bootstrapUrl` itself.

---

## Troubleshooting

| Symptom | Cause / Fix |
|---------|-------------|
| `gateway SSO discovery failed: 404 at .well-known/oauth-authorization-server` | No `bootstrapHeaders` set → app fell back to device‑code OAuth against the URL's origin. Add any static header (e.g. `"X-Config": "team"`). |
| Fetch fails / config not applied | URL is a `github.com/.../blob/...` page (HTML). Use the `raw.githubusercontent.com` URL. |
| `404` from `raw.githubusercontent.com` | Repo is private. Make it public, or add a token via `bootstrapHeaders` (`{ "Authorization": "Bearer <token>" }`). |
| Change not showing up | GitHub CDN cache (~5 min) or app not relaunched. Wait, then fully quit and reopen. |
| Settings still editable | You used the local‑file method (not MDM). That's expected — local config is not enforced. Use MDM to lock it. |
| Users still see claude.ai sign‑in | Add `"disableDeploymentModeChooser": true` to `default.json` to hide it and show only your deployment. |
| App won't stop on rollout | Windows image name isn't `Claude.exe`. Update the process name in the script. |

---

## Advanced — per‑group configuration (Pattern B)

The method above serves **one** `default.json` to everyone. To serve a **different
config per user group** without maintaining a file per machine, use the
`bootstrap-server/` Lambda: every machine keeps the *same* bootstrap pointer, but
the pointer targets an OIDC‑authenticated endpoint that reads the signed‑in
user's group/role claim and returns that group's overlay.

* `bootstrap-server/index.mjs` — token verification + group→config selection.
* `bootstrap-server/configs.mjs` — a shared base plus per‑group deltas.
* Requires `bootstrapOidc` in the client config and a real HTTPS endpoint
  (API Gateway + Lambda); a static GitHub file cannot branch on identity.

See the comments in those files for deployment and IdP setup.
