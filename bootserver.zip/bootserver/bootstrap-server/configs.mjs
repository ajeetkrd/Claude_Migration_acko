// Config overlays: one shared BASE, plus per-group deltas layered on top.
// Keep secrets/credentials out of source control if this repo is shared —
// inject them from Secrets Manager/SSM at runtime instead of hard-coding.

// Everything every group gets. Mirrors Ajeet's working config.
export const BASE = {
  $schemaVersion: 1,

  inferenceProvider: 'bedrock',
  inferenceCredentialKind: 'interactive',
  inferenceBedrockRegion: 'ap-south-1',
  inferenceBedrockSsoStartUrl: 'https://ajeetdubey.awsapps.com/start',
  inferenceBedrockSsoRegion: 'us-east-1',
  inferenceBedrockSsoAccountId: '708895069383',
  inferenceBedrockSsoRoleName: 'ClaudeBedrock',

  chatTabEnabled: true,
  chatAdvancedFileAnalysisEnabled: true,
  isDesktopExtensionEnabled: true,

  modelPrefer1mContext: true,
  inferenceModels: [
    {
      name: 'arn:aws:bedrock:ap-south-1:708895069383:application-inference-profile/rq8oqww71fqm',
      labelOverride: 'Infr Profile Opus',
      supports1m: true,
      prefer1m: true,
      anthropicFamilyTier: 'opus',
      isFamilyDefault: true,
    },
    {
      name: 'arn:aws:bedrock:ap-south-1:708895069383:application-inference-profile/3pnu5nz7ge2o',
      labelOverride: 'infr profile sonnet',
      anthropicFamilyTier: 'sonnet',
    },
    {
      name: 'arn:aws:bedrock:ap-south-1:708895069383:application-inference-profile/gfx94loxwuuj',
      labelOverride: 'infr profile haiku',
      anthropicFamilyTier: 'haiku',
    },
  ],
  defaultModelEffort: 'high',
  alwaysStartWithDefaultModel: true,

  inferenceModelPricingEnabled: true,
  inferenceModelPricingMultiplier: 1,
  inferenceModelPricing: [
    {
      name: 'global.anthropic.claude-opus-4-8',
      inputPerMtok: 5,
      outputPerMtok: 25,
      cacheReadPerMtok: 6.25,
      cacheWritePerMtok: 0.5,
    },
  ],

  toolSearchEnabled: true,
  skipWebFetchPreflight: true,
  disableDeepLinkRegistration: true,
  deploymentDisplayName: 'via Bedrock',
};

// Per-group deltas. Top-level keys here replace the same key in BASE.
export const GROUP_OVERLAYS = {
  // Power users / engineering: broad egress, all tools, longer token window.
  power: {
    deploymentDisplaySubtitle: 'engineering',
    coworkEgressAllowedHosts: ['*'],
    inferenceTokenWindowHours: 720,
    inferenceMaxTokensPerWindow: 200_000_000,
  },

  // Restricted group: no web egress, web tools off, tighter token cap.
  restricted: {
    deploymentDisplaySubtitle: 'restricted',
    coworkEgressAllowedHosts: [],
    disabledBuiltinTools: ['WebSearch', 'WebFetch'],
    inferenceTokenWindowHours: 720,
    inferenceMaxTokensPerWindow: 20_000_000,
  },

  // Everyone else.
  default: {
    deploymentDisplaySubtitle: 'standard',
    coworkEgressAllowedHosts: ['*.amazonaws.com'],
    inferenceTokenWindowHours: 720,
    inferenceMaxTokensPerWindow: 50_000_000,
  },
};

// Map the token's group/role memberships to a profile key above.
// Order matters: most restrictive wins if a user is in several groups.
export function pickProfile(memberships = []) {
  const set = new Set(memberships);
  if (set.has('claude-restricted')) return 'restricted';
  if (set.has('claude-power-user')) return 'power';
  return 'default';
}

// Shallow top-level merge: an overlay key fully replaces the BASE key
// (arrays/objects are not deep-merged — intentional, so a group can e.g.
// replace the whole egress list).
export function mergeConfig(base, overlay) {
  return { ...base, ...overlay };
}
