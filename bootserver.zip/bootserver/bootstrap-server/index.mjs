// Bootstrap config server — Pattern B (one URL, per-group response keyed on OIDC claims)
//
// Claude Desktop signs the user in against your IdP (via the `bootstrapOidc`
// client config), then calls this endpoint with `Authorization: Bearer <token>`.
// We verify the token, read the group/role claim, and return that group's
// config overlay. The app applies it and marks those settings read-only.
//
// Runtime: Node 20 Lambda behind API Gateway (HTTP API) or a Lambda Function URL.
// Dependency: `jose` (JWT verification against the IdP's JWKS).

import { createRemoteJWKSet, jwtVerify } from 'jose';
import { BASE, GROUP_OVERLAYS, pickProfile, mergeConfig } from './configs.mjs';

// ---- Environment (set in Lambda config) -----------------------------------
// OIDC_ISSUER   e.g. https://login.microsoftonline.com/<tenant-id>/v2.0   (Entra)
//               e.g. https://<org>.okta.com/oauth2/<authServerId>          (Okta)
// OIDC_AUDIENCE the value the token's `aud` must equal. For an id_token this
//               is your app's clientId; for an access_token it's your API's
//               identifier. Log the claims once (see below) to confirm which
//               token Claude Desktop actually sends, then pin this.
// JWKS_URI      the IdP's signing-key set, from <issuer>/.well-known/openid-configuration
const { OIDC_ISSUER, OIDC_AUDIENCE, JWKS_URI } = process.env;

const JWKS = createRemoteJWKSet(new URL(JWKS_URI));

export const handler = async (event) => {
  // API Gateway HTTP API and Function URLs both lowercase header keys.
  const headers = event.headers || {};
  const authz = headers.authorization || headers.Authorization || '';
  const token = authz.replace(/^Bearer\s+/i, '').trim();

  if (!token) return json(401, { error: 'missing_bearer_token' });

  let claims;
  try {
    ({ payload: claims } = await jwtVerify(token, JWKS, {
      issuer: OIDC_ISSUER,
      audience: OIDC_AUDIENCE,
    }));
  } catch (err) {
    // Do NOT leak token contents. Log only the failure reason.
    console.warn('token_verification_failed', err.code || err.message);
    return json(401, { error: 'invalid_token' });
  }

  // Uncomment ONCE during setup to see which claims/token type arrive,
  // then re-comment (claims can contain PII):
  // console.log('claims', JSON.stringify(claims));

  // Entra surfaces app roles as `roles`; Okta custom auth servers use `groups`.
  const memberships = claims.roles || claims.groups || [];
  const profile = pickProfile(memberships);            // 'restricted' | 'power' | 'default'

  const config = mergeConfig(BASE, GROUP_OVERLAYS[profile] || {});

  // Optional: let clients re-fetch on a schedule (epoch seconds).
  config.expiresAt = Math.floor(Date.now() / 1000) + 3600;

  return json(200, config, { user: claims.preferred_username || claims.sub, profile });
};

function json(statusCode, body, log) {
  if (log) console.log('served', JSON.stringify(log));
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      // CRITICAL: responses are per-user and carry credentials/config.
      // Without no-store a CDN/proxy could serve one user's config to another.
      'Cache-Control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}
