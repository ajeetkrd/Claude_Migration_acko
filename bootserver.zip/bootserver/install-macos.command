#!/bin/bash
# Double-clickable macOS launcher for configure_bootstrap.py.
# Runs the Python configurator with --force-quit, then keeps the window open.
# Distribute alongside configure_bootstrap.py (same folder).

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$DIR/configure_bootstrap.py"

if [ ! -f "$SCRIPT" ]; then
  echo "ERROR: configure_bootstrap.py not found next to this launcher."
  read -r -p "Press Enter to close..."
  exit 1
fi

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "ERROR: Python 3 not found on PATH. Install it (e.g. from python.org) and retry."
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "Configuring Claude Desktop bootstrap..."
"$PY" "$SCRIPT" --force-quit "$@"
code=$?

echo
if [ "$code" -eq 0 ]; then
  echo "Success. Reopen Claude Desktop and approve the org-settings dialog if shown."
else
  echo "Finished with errors (exit $code). See messages above."
fi
read -r -p "Press Enter to close..."
exit "$code"
