#!/usr/bin/env python3
"""
configure_bootstrap.py — provision the Claude Desktop (3P) bootstrap config
on an end-user machine and make it the applied configuration.

What it does
------------
1. Locates the per-user `configLibrary` directory for this OS.
2. Writes a `<uuid>.json` file containing the bootstrap loader config.
3. Creates or updates `_meta.json` so the new config is listed AND applied.

Design choices
--------------
* Idempotent: re-running finds an existing entry with the same bootstrapUrl
  and updates it in place instead of piling up duplicates.
* Non-destructive: other saved configurations already in `_meta.json`
  (e.g. a personal "claude" profile) are preserved.
* Cross-platform: macOS, Windows, Linux.

Usage
-----
    python3 configure_bootstrap.py                 # use the defaults below
    python3 configure_bootstrap.py --name "Org Bootstrap" \
        --url  "https://raw.githubusercontent.com/ajeetkrd/bedrock-model-usage-claude/main/default.json" \
        --header "X-Config=ajeet"
    python3 configure_bootstrap.py --dry-run       # show what it would do

IMPORTANT: fully quit Claude Desktop before running; config is read at launch.
The app must relaunch to pick up the change (and the user approves the
one-time "Apply settings from your organization?" dialog).
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

# ---- Defaults (edit these, or override on the command line) ----------------
DEFAULT_NAME = "Org Bootstrap"
DEFAULT_URL = "https://raw.githubusercontent.com/ajeetkrd/bedrock-model-usage-claude/main/default.json"
DEFAULT_HEADERS = {"X-Config": "ajeet"}  # any static header -> skips device-code OAuth
DEFAULT_ENABLED = True

# Process/app identity of Claude Desktop, per OS. Adjust WINDOWS_IMAGE if your
# install uses a different executable name (check Task Manager → Details).
MACOS_APP_NAME = "Claude"        # osascript app name / pgrep -x match
WINDOWS_IMAGE = "Claude.exe"     # taskkill /IM value
LINUX_PROC = "Claude"            # pgrep -x match


def claude_is_running() -> bool:
    """Best-effort check for a running Claude Desktop process."""
    try:
        if os.name == "nt":
            out = subprocess.run(
                ["tasklist", "/FI", f"IMAGENAME eq {WINDOWS_IMAGE}"],
                capture_output=True, text=True,
            ).stdout or ""
            return WINDOWS_IMAGE.lower() in out.lower()
        # macOS + Linux
        name = MACOS_APP_NAME if sys.platform == "darwin" else LINUX_PROC
        if shutil.which("pgrep"):
            return subprocess.run(["pgrep", "-x", name], capture_output=True).returncode == 0
    except (OSError, subprocess.SubprocessError):
        pass
    return False  # can't tell -> assume not running, but caller may still warn


def quit_claude(timeout: float = 10.0) -> bool:
    """Ask Claude Desktop to quit, escalating to a force-kill on timeout.

    Returns True if the app is confirmed stopped (or was never running).
    """
    if not claude_is_running():
        print("Claude Desktop: not running.")
        return True

    print("Claude Desktop: requesting graceful quit...")
    try:
        if sys.platform == "darwin":
            subprocess.run(["osascript", "-e", f'tell application "{MACOS_APP_NAME}" to quit'],
                           capture_output=True)
        elif os.name == "nt":
            subprocess.run(["taskkill", "/IM", WINDOWS_IMAGE], capture_output=True)  # no /F = graceful
        else:
            subprocess.run(["pkill", "-TERM", "-x", LINUX_PROC], capture_output=True)
    except (OSError, subprocess.SubprocessError) as e:
        print(f"  (graceful quit command failed: {e})")

    deadline = time.time() + timeout
    while time.time() < deadline:
        if not claude_is_running():
            print("Claude Desktop: exited cleanly.")
            return True
        time.sleep(0.5)

    print("Claude Desktop: still running after timeout; forcing stop...")
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/IM", WINDOWS_IMAGE], capture_output=True)
        else:
            name = MACOS_APP_NAME if sys.platform == "darwin" else LINUX_PROC
            subprocess.run(["pkill", "-9", "-x", name], capture_output=True)
    except (OSError, subprocess.SubprocessError) as e:
        print(f"  (force-kill command failed: {e})")

    time.sleep(1.0)
    if claude_is_running():
        print("WARNING: Claude Desktop still appears to be running. Close it manually.")
        return False
    print("Claude Desktop: force-stopped.")
    return True


def config_library_dir() -> Path:
    """Per-user configLibrary path for the current OS (Claude Desktop 3P)."""
    if sys.platform == "darwin":  # macOS
        return Path.home() / "Library" / "Application Support" / "Claude-3p" / "configLibrary"
    if os.name == "nt":  # Windows
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
        return Path(base) / "Claude-3p" / "configLibrary"
    # Linux / other
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else (Path.home() / ".config")
    return base / "Claude-3p" / "configLibrary"


def load_meta(meta_path: Path) -> dict:
    if meta_path.exists():
        try:
            data = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data.setdefault("entries", [])
                return data
        except (json.JSONDecodeError, OSError) as e:
            # Fail loud: a corrupt meta shouldn't be silently overwritten.
            raise SystemExit(f"ERROR: could not parse existing {meta_path}: {e}")
    return {"entries": []}


def find_existing_bootstrap_id(cfg_dir: Path, meta: dict, url: str) -> str | None:
    """Return the id of an existing config whose bootstrapUrl matches, if any."""
    for entry in meta.get("entries", []):
        cid = entry.get("id")
        if not cid:
            continue
        cfg_file = cfg_dir / f"{cid}.json"
        if not cfg_file.exists():
            continue
        try:
            existing = json.loads(cfg_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if isinstance(existing, dict) and existing.get("bootstrapUrl") == url:
            return cid
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="Configure Claude 3P bootstrap for this user.")
    ap.add_argument("--name", default=DEFAULT_NAME, help="Display name for the configuration.")
    ap.add_argument("--url", default=DEFAULT_URL, help="Bootstrap config URL (raw JSON, HTTPS).")
    ap.add_argument("--header", action="append", default=None,
                    help="Static header as Name=Value (repeatable). Defaults to X-Config=ajeet.")
    ap.add_argument("--no-header", action="store_true",
                    help="Send no bootstrapHeaders (only use if the URL needs no auth-mode nudge).")
    ap.add_argument("--no-apply", action="store_true",
                    help="Write the config but do NOT set it as the applied one.")
    ap.add_argument("--force-quit", action="store_true",
                    help="Quit Claude Desktop (graceful, then force) before writing config.")
    ap.add_argument("--quit-timeout", type=float, default=10.0,
                    help="Seconds to wait for a graceful quit before forcing (default 10).")
    ap.add_argument("--dry-run", action="store_true", help="Print actions without writing files.")
    args = ap.parse_args()

    # Build headers.
    if args.no_header:
        headers = None
    elif args.header:
        headers = {}
        for h in args.header:
            if "=" not in h:
                raise SystemExit(f"ERROR: --header must be Name=Value, got: {h!r}")
            k, v = h.split("=", 1)
            headers[k.strip()] = v.strip()
    else:
        headers = dict(DEFAULT_HEADERS)

    cfg_dir = config_library_dir()
    meta_path = cfg_dir / "_meta.json"

    # Assemble the bootstrap config body.
    body: dict = {"bootstrapEnabled": DEFAULT_ENABLED, "bootstrapUrl": args.url}
    if headers:
        body["bootstrapHeaders"] = headers

    meta = load_meta(meta_path) if not args.dry_run else load_meta(meta_path)

    existing_id = find_existing_bootstrap_id(cfg_dir, meta, args.url)
    cfg_id = existing_id or str(uuid.uuid4())
    cfg_file = cfg_dir / f"{cfg_id}.json"

    action = "UPDATE existing" if existing_id else "CREATE new"
    print(f"configLibrary : {cfg_dir}")
    print(f"config id     : {cfg_id}  ({action})")
    print(f"name          : {args.name}")
    print(f"bootstrapUrl  : {args.url}")
    print(f"headers       : {headers if headers else '(none)'}")
    print(f"apply as active: {not args.no_apply}")

    if args.dry_run:
        print("\n--dry-run: no files written.")
        if args.force_quit:
            print("Would quit Claude Desktop before writing.")
        print("Would write config:\n" + json.dumps(body, indent=2))
        return 0

    # Ensure the app is not running: writing _meta.json under a live app risks
    # the app overwriting it on exit and losing this change.
    if args.force_quit:
        if not quit_claude(timeout=args.quit_timeout):
            print("ERROR: could not stop Claude Desktop; aborting to avoid a lost write.")
            return 1
    elif claude_is_running():
        print("ERROR: Claude Desktop is running. Quit it first, or re-run with --force-quit.")
        return 1

    # Write files.
    cfg_dir.mkdir(parents=True, exist_ok=True)
    cfg_file.write_text(json.dumps(body, indent=2) + "\n", encoding="utf-8")

    # Ensure an entry exists in _meta.json.
    entries = meta.setdefault("entries", [])
    if not any(e.get("id") == cfg_id for e in entries):
        entries.append({"id": cfg_id, "name": args.name})
    else:
        for e in entries:
            if e.get("id") == cfg_id:
                e["name"] = args.name

    if not args.no_apply:
        meta["appliedId"] = cfg_id

    meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%SZ")
    print(f"\nDone ({stamp}).")
    print("Fully quit and reopen Claude Desktop, then approve the org-settings dialog if shown.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
