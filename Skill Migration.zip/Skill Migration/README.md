# Claude → Claude-3p Skill Migration

A DIY, self-service utility that migrates your skills from the **Claude (1P)** desktop
app into the **Claude-3p** desktop app. It packages each skill you don't already have
into a `.skill` file that you install with the app's built-in **Save skill** button.

Runs entirely on your own machine — nothing is uploaded anywhere.

---

## TL;DR

```bash
python3 claude_skill_packager.py            # creates .skill files in ~/Downloads/claude-skill-packages
```

Then open each `.skill` in Claude-3p and click **Save skill**. Done.

---

## Why a packager, and not a plain "copy the folders" script

This is the important part — it explains why the obvious approach fails.

Both apps keep a skills bundle on disk at:

```
<App Support>/<AppName>/local-agent-mode-sessions/skills-plugin/<uuid>/<uuid>/
    manifest.json
    skills/
        <skill-name>/
            SKILL.md
            ...
```

- The **Claude (1P)** app treats its on-disk `skills/` folder as the source of truth.
- The **Claude-3p** app does **not**. Its skills live in your **account**, and the
  on-disk folder is only a *cache* that the app **rebuilds from scratch on every launch**.

So if you copy skill folders into the Claude-3p cache, they work for the current session
and then **vanish on the next restart** when the app rebuilds the cache. (This was
confirmed by testing: copied skills reappeared as "to migrate" after a restart.)

The only durable way to add a skill to Claude-3p is the app's **Save skill** button,
which accepts a `.skill` package. This utility automates everything up to that click —
the click itself is the account-level write and cannot be scripted, by design.

---

## What the utility does

1. **Auto-discovers** the Claude (source) and Claude-3p (target) skill bundles for the
   current user — no hard-coded UUIDs, so it works for anyone on any Mac.
2. **Skips** skills already present in Claude-3p (so you only migrate what's missing).
3. **Packages** each remaining skill directory into `<name>.skill` — a zip that preserves
   **all** files in the skill (SKILL.md plus any scripts, references, or assets).
4. **Writes** an `INSTALL.txt` next to the packages with click-by-click install steps.

Default output folder: `~/Downloads/claude-skill-packages`

---

## Prerequisites

- macOS (Windows/Linux paths are handled too, but the app folder names may differ).
- **Python 3.8+** — check with `python3 --version`. Pre-installed on macOS; if missing,
  install from <https://www.python.org/downloads/> or `brew install python`.
- Both the Claude and Claude-3p desktop apps installed and launched at least once
  (so their skill bundles exist on disk).
- No third-party packages required — standard library only.

---

## Step-by-step

### Step 1 — Get the script

Save `claude_skill_packager.py` anywhere convenient, e.g. `~/Downloads`.

### Step 2 — See what's there (optional but recommended)

```bash
python3 claude_skill_packager.py --list
```

This prints the discovered Claude and Claude-3p bundles and the skills in each, so you
can confirm it found the right folders before doing anything.

### Step 3 — Preview the migration (dry run)

```bash
python3 claude_skill_packager.py --dry-run
```

Shows which skills would be packaged and which are skipped (already in Claude-3p).
No files are written.

### Step 4 — Create the packages

```bash
python3 claude_skill_packager.py
```

Writes one `<name>.skill` per missing skill, plus `INSTALL.txt`, into
`~/Downloads/claude-skill-packages`.

Look inside with:

```bash
ls -la ~/Downloads/claude-skill-packages
open  ~/Downloads/claude-skill-packages     # opens the folder in Finder
```

> Note: `~/Downloads/claude-skill-packages` on its own line in the terminal gives
> `zsh: permission denied` — that's just zsh trying to *run* the folder. Use `ls`,
> `open`, or `cd` in front of it.

### Step 5 — Install each skill into Claude-3p (the one manual click)

For each `.skill` file:

1. Open the **Claude-3p** desktop app.
2. **Drag the `.skill` file into a chat**, or double-click it in Finder.
3. Click the **Save skill** button that appears.
4. Repeat for the rest.

Saved skills persist across restarts because they're now in your account.

### Step 6 — Verify it stuck

Fully **quit and reopen** Claude-3p, then ask it to list your skills (or re-run
`python3 claude_skill_packager.py --dry-run` — the migrated skills should now show as
skipped/already present). If they survive the restart, the migration is durable.

---

## Command reference

| Command | What it does |
|---|---|
| `python3 claude_skill_packager.py` | Package missing skills → default output folder |
| `--list` | List discovered bundles and their skills, then exit |
| `--dry-run` | Show what would be packaged; write nothing |
| `--all` | Package **every** source skill, even ones already in Claude-3p |
| `--flat` | Put `SKILL.md` at the zip root instead of under `<name>/` |
| `--out DIR` | Write packages to `DIR` instead of `~/Downloads/claude-skill-packages` |
| `--source PATH` | Override source bundle (folder containing `manifest.json` + `skills/`) |
| `--target PATH` | Override target bundle (used only to skip already-present skills) |

---

## Distributing to other people

Share a single file: `claude_skill_packager.py`. Each person runs it on their own Mac; it
auto-detects their home directory and app folders, so there's nothing to configure. Tell
them the two-line version:

> 1. `python3 claude_skill_packager.py`
> 2. Open each `.skill` in Claude-3p and click **Save skill**.

---

## Troubleshooting

**"no Claude skills bundle found"**
The app hasn't created its on-disk bundle, or it lives somewhere unexpected. Launch the
app once, then re-run. If it still fails, find the folder that directly contains
`manifest.json` and `skills/` and pass it with `--source` / `--target`.

**"NOTE: N bundles found; using newest"**
More than one session bundle exists. The script picks the most recently modified one. If
that's wrong, point at the right one explicitly with `--source` / `--target`.

**The `.skill` won't install / "Save skill" errors**
There are two possible archive layouts. The default wraps files under `<name>/`; some app
builds expect a flat layout. Re-package with `--flat` and try that file:
```bash
python3 claude_skill_packager.py --flat
```
**Test one skill end-to-end (package → Save skill → restart → confirm it persists)
before distributing to others**, so you know which layout your build accepts.

**Skill installed but a bundled script/asset is missing**
The `.skill` package preserves all files, so drag-installing the `.skill` should keep
them. If you instead migrated via the account API (SKILL.md only), re-do it with the
`.skill` package.

**`zsh: permission denied: <folder>`**
You typed a folder path as a command. Prefix it with `ls`, `cd`, or `open`.

---

## Limitations / known constraints

- The final **Save skill** click cannot be automated — the Claude-3p account store has no
  external write path on purpose. Realistic goal is "one script + one click per skill."
- Skill **identity is the folder name.** If a skill exists in Claude-3p under the same
  name, it's skipped (its version is never touched), even if contents differ. Use `--all`
  to package everything and decide per-skill at install time.
- The archive layout (`<name>/` vs `--flat`) that the installer accepts hasn't been
  pinned down for every app build — verify with one skill first (see Troubleshooting).
