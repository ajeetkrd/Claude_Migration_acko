#!/usr/bin/env python3
"""
claude_skill_packager.py

DIY, self-service migration of Claude "skills" from the Claude (1P) desktop app
into the Claude-3p desktop app  by packaging each skill as a `.skill` file that
the user installs with the app's built-in "Save skill" button.

WHY THIS DESIGN
---------------
Claude-3p stores skills at the ACCOUNT level, not on disk. The on-disk
`skills-plugin/<uuid>/<uuid>/skills/` folder is a cache the app REBUILDS on every
launch, so copying skill folders into it does NOT persist. The only durable,
externally-reachable path is the app's "Save skill" install button, which accepts
a `.skill` package (a zip of a skill directory containing SKILL.md).

So this utility does the automatable 90%:
  1. Auto-discovers the source (Claude) skills bundle for the current user.
  2. Skips skills already present in the target (Claude-3p) bundle.
  3. Zips each remaining skill directory into <name>.skill in an output folder,
     preserving ALL files (SKILL.md + any scripts/assets).
  4. Writes an INSTALL.txt telling the user to open each .skill and click
     "Save skill". That click is the account-level write  the one step that
     cannot be scripted, by design.

Runs entirely on the user's own machine, so it CAN read the app-support folders
(the sandbox restriction that blocks the assistant does not apply to the user).

USAGE
-----
    python3 claude_skill_packager.py                 # package new skills -> ~/Downloads/claude-skill-packages
    python3 claude_skill_packager.py --list          # show discovered bundles & skills, exit
    python3 claude_skill_packager.py --dry-run        # show what WOULD be packaged
    python3 claude_skill_packager.py --all            # package every source skill (ignore skip-existing)
    python3 claude_skill_packager.py --out ~/Desktop/skills
    python3 claude_skill_packager.py --flat           # put SKILL.md at the zip root instead of <name>/SKILL.md
    python3 claude_skill_packager.py --source PATH --target PATH
        # override auto-discovery (PATH = folder that directly contains manifest.json + skills/)

After it runs: open each *.skill in Finder (double-click) OR drag it into a
Claude-3p chat, then click "Save skill". Saved skills persist across restarts.
"""

from __future__ import annotations

import argparse
import os
import sys
import zipfile
from pathlib import Path

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

SOURCE_APP = "Claude"       # 1P desktop app folder name
TARGET_APP = "Claude-3p"    # 3P desktop app folder name

APP_SUPPORT_CANDIDATES = [
    Path.home() / "Library" / "Application Support",                                   # macOS
    Path(os.environ["APPDATA"]) if os.environ.get("APPDATA") else None,                # Windows
    Path.home() / ".config",                                                           # Linux
]

BUNDLE_GLOB = os.path.join("local-agent-mode-sessions", "skills-plugin", "*", "*")

DEFAULT_OUT = Path.home() / "Downloads" / "claude-skill-packages"


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def log(msg: str = "") -> None:
    print(msg, flush=True)


def app_support_root() -> Path:
    for cand in APP_SUPPORT_CANDIDATES:
        if cand and cand.exists():
            return cand
    return Path.home() / "Library" / "Application Support"


def discover_bundles(app_name: str):
    """Bundles (folder with manifest.json + skills/) for an app, newest first."""
    root = app_support_root() / app_name
    bundles = []
    if not root.exists():
        return bundles
    for candidate in root.glob(BUNDLE_GLOB):
        if not candidate.is_dir():
            continue
        manifest = candidate / "manifest.json"
        skills_dir = candidate / "skills"
        if manifest.exists() and skills_dir.is_dir():
            bundles.append({"root": candidate, "skills_dir": skills_dir,
                            "mtime": manifest.stat().st_mtime})
    bundles.sort(key=lambda b: b["mtime"], reverse=True)
    return bundles


def resolve_bundle(app_name: str, explicit: str | None, label: str, required: bool):
    if explicit:
        root = Path(explicit).expanduser().resolve()
        skills_dir = root / "skills"
        if not skills_dir.is_dir():
            sys.exit(f"ERROR: --{label} path has no skills/ subfolder: {root}")
        return {"root": root, "skills_dir": skills_dir}
    found = discover_bundles(app_name)
    if not found:
        if required:
            sys.exit(
                f"ERROR: no {app_name} skills bundle found under "
                f"{app_support_root() / app_name / 'local-agent-mode-sessions' / 'skills-plugin'}\n"
                f"       Pass --{label} <path> to point at it manually."
            )
        return None
    chosen = found[0]
    if len(found) > 1:
        log(f"NOTE: {len(found)} {app_name} bundles found; using newest:\n      {chosen['root']}")
        log(f"      (override with --{label} if wrong)")
    return chosen


def skill_names(skills_dir: Path):
    return sorted(p.name for p in skills_dir.iterdir()
                  if p.is_dir() and not p.name.startswith("."))


def package_skill(skill_dir: Path, out_dir: Path, flat: bool) -> Path:
    """Zip a skill directory into <name>.skill. Returns the output path."""
    name = skill_dir.name
    out_path = out_dir / f"{name}.skill"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in sorted(skill_dir.rglob("*")):
            if file.is_dir():
                continue
            rel = file.relative_to(skill_dir)          # e.g. SKILL.md, scripts/run.py
            arc = rel if flat else Path(name) / rel     # flat: SKILL.md at root; else <name>/SKILL.md
            zf.write(file, arcname=str(arc))
    return out_path


def write_install_readme(out_dir: Path, packaged: list[str]) -> None:
    readme = out_dir / "INSTALL.txt"
    lines = [
        "Claude skill migration  install instructions",
        "=" * 46,
        "",
        f"{len(packaged)} skill package(s) were created in this folder:",
        *[f"  - {n}.skill" for n in packaged],
        "",
        "To install each one into Claude-3p (persists across restarts):",
        "  1. Open the Claude-3p desktop app.",
        "  2. Drag a .skill file into a chat  OR  double-click it in Finder.",
        "  3. Click the 'Save skill' button that appears.",
        "  4. Repeat for each .skill file.",
        "",
        "Why the click is required: Claude-3p stores skills in your account, not",
        "on disk. 'Save skill' is the only durable write path  copying folders",
        "into the app's cache gets wiped on the next launch.",
    ]
    readme.write_text("\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #

def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Package Claude (1P) skills as .skill files for install into Claude-3p."
    )
    ap.add_argument("--list", action="store_true",
                    help="List discovered bundles and their skills, then exit.")
    ap.add_argument("--dry-run", action="store_true",
                    help="Show what would be packaged without writing files.")
    ap.add_argument("--all", action="store_true",
                    help="Package every source skill, even ones already in Claude-3p.")
    ap.add_argument("--flat", action="store_true",
                    help="Put SKILL.md at the zip root instead of under <name>/.")
    ap.add_argument("--out", metavar="DIR", default=str(DEFAULT_OUT),
                    help=f"Output folder for .skill files (default: {DEFAULT_OUT}).")
    ap.add_argument("--source", metavar="PATH",
                    help="Explicit source bundle root (contains manifest.json + skills/).")
    ap.add_argument("--target", metavar="PATH",
                    help="Explicit target bundle root; used only to skip already-present skills.")
    args = ap.parse_args(argv)

    if args.list:
        for app in (SOURCE_APP, TARGET_APP):
            log(f"\n{app} bundles:")
            found = discover_bundles(app)
            if not found:
                log("  (none found)")
            for b in found:
                names = skill_names(b["skills_dir"])
                log(f"  {b['root']}")
                log(f"      {len(names)} skills: {', '.join(names)}")
        return 0

    source = resolve_bundle(SOURCE_APP, args.source, "source", required=True)
    target = resolve_bundle(TARGET_APP, args.target, "target", required=False)

    src_names = skill_names(source["skills_dir"])
    tgt_names = set(skill_names(target["skills_dir"])) if target else set()

    if args.all:
        to_pack = src_names
        skipped = []
    else:
        to_pack = [n for n in src_names if n not in tgt_names]
        skipped = [n for n in src_names if n in tgt_names]

    log("=" * 68)
    log("Claude -> Claude-3p  .skill packager")
    log("=" * 68)
    log(f"Source (Claude)    : {source['root']}")
    log(f"Target (Claude-3p) : {target['root'] if target else '(not found  packaging all source skills)'}")
    log("")
    log(f"Skills in source   : {len(src_names)}")
    if not args.all:
        log(f"Already in target  : {len(skipped)}  -> skipped: {', '.join(skipped) or '(none)'}")
    log(f"To package         : {len(to_pack)}  -> {', '.join(to_pack) or '(none)'}")
    log("")

    if not to_pack:
        log("Nothing to package. Done.")
        return 0

    if args.dry_run:
        log("DRY RUN  no files written. Re-run without --dry-run to create the .skill packages.")
        return 0

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    packaged = []
    for name in to_pack:
        try:
            out_path = package_skill(source["skills_dir"] / name, out_dir, args.flat)
            packaged.append(name)
            size_kb = out_path.stat().st_size / 1024
            log(f"  packaged  {name}.skill  ({size_kb:.1f} KB)")
        except Exception as exc:  # noqa: BLE001
            log(f"  FAILED    {name}: {exc}")

    if packaged:
        write_install_readme(out_dir, packaged)
        log("")
        log("-" * 68)
        log(f"Done. {len(packaged)} .skill package(s) written to:")
        log(f"  {out_dir}")
        log("")
        log("NEXT STEP (installs to your account, survives restart):")
        log("  Open each .skill in Claude-3p and click 'Save skill'.")
        log("  See INSTALL.txt in that folder for details.")
        log("-" * 68)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
