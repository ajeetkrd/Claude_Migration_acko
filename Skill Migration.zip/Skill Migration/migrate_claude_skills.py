#!/usr/bin/env python3
"""
migrate_claude_skills.py

Portable, per-user migration of Claude "skills-plugin" skills from the
Claude (1P) desktop app into the Claude-3p desktop app.

WHAT IT DOES
------------
Both apps store a skills bundle at:

    <APP_SUPPORT>/<AppName>/local-agent-mode-sessions/skills-plugin/<uuid>/<uuid>/
        manifest.json
        skills/
            <skill-name>/
                SKILL.md
                ...

This script:
  1. Auto-discovers the source (Claude) and target (Claude-3p) bundles for the
     CURRENT user  no hard-coded UUIDs, so it works for any user on any Mac.
  2. Copies every skill folder that is NOT already present in the target
     (conflict policy = SKIP EXISTING; target versions are never touched).
  3. Merges a registry entry for each migrated skill into the target
     manifest.json, after taking a timestamped backup of that manifest.
  4. Defaults to a DRY RUN. Nothing is written until you pass --apply.

USAGE
-----
    python3 migrate_claude_skills.py                 # dry run  shows the plan
    python3 migrate_claude_skills.py --apply         # actually migrate
    python3 migrate_claude_skills.py --list          # just show discovered bundles
    python3 migrate_claude_skills.py --source PATH --target PATH --apply
        # override auto-discovery with explicit bundle roots (the folder that
        # directly contains manifest.json and skills/)

NOTES
-----
- Skill identity == the skill's folder name. If target/skills/<name> exists,
  it is skipped, whatever the manifest says.
- Manifest merge is schema-adaptive and conservative: it only ADDS entries for
  migrated skills, never edits or removes existing ones. If the manifest schema
  can't be understood, folders are still copied and a warning is printed.
- macOS paths are used by default. To run elsewhere, pass --source/--target,
  or edit APP_SUPPORT_CANDIDATES below.
"""

from __future__ import annotations

import argparse
import copy
import datetime as _dt
import json
import os
import shutil
import sys
from pathlib import Path

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

SOURCE_APP = "Claude"       # 1P desktop app folder name
TARGET_APP = "Claude-3p"    # 3P desktop app folder name

# Where "Application Support" (or the OS equivalent) lives, per platform.
# The first candidate that exists for the current user wins.
APP_SUPPORT_CANDIDATES = [
    Path.home() / "Library" / "Application Support",           # macOS
    Path(os.environ.get("APPDATA", "")) if os.environ.get("APPDATA") else None,  # Windows
    Path.home() / ".config",                                   # Linux
]

# Relative path from an app folder to the parent of the <uuid>/<uuid> bundles.
BUNDLE_GLOB = os.path.join("local-agent-mode-sessions", "skills-plugin", "*", "*")

# Manifest keys that commonly hold the list of registered skills.
KNOWN_REGISTRY_KEYS = ("skills", "entries", "plugins", "items")

# Keys inside a manifest entry that may hold the skill's name/identity.
NAME_KEYS = ("name", "id", "slug", "skill", "skillName", "skill_name")

# Keys inside a manifest entry that may hold the skill's folder path.
PATH_KEYS = ("path", "dir", "directory", "location", "source")


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

def _now_stamp() -> str:
    return _dt.datetime.now().strftime("%Y%m%d-%H%M%S")


def log(msg: str = "") -> None:
    print(msg, flush=True)


def app_support_root() -> Path:
    for cand in APP_SUPPORT_CANDIDATES:
        if cand and cand.exists():
            return cand
    # Fall back to the macOS location even if missing, so error messages make sense.
    return Path.home() / "Library" / "Application Support"


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def dump_json(path: Path, data) -> None:
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


# --------------------------------------------------------------------------- #
# Bundle discovery
# --------------------------------------------------------------------------- #

def discover_bundles(app_name: str):
    """Return a list of bundle dicts for the given app, newest first.

    A 'bundle' is a folder that directly contains manifest.json and skills/.
    """
    root = app_support_root() / app_name
    bundles = []
    if not root.exists():
        return bundles

    for candidate in root.glob(BUNDLE_GLOB):
        if not candidate.is_dir():
            continue
        manifest = candidate / "manifest.json"
        skills_dir = candidate / "skills"
        if manifest.exists() and skills_dir.is_dir():
            bundles.append(
                {
                    "root": candidate,
                    "manifest": manifest,
                    "skills_dir": skills_dir,
                    "mtime": manifest.stat().st_mtime,
                }
            )
    # Newest manifest first  most likely the active bundle.
    bundles.sort(key=lambda b: b["mtime"], reverse=True)
    return bundles


def pick_bundle(app_name: str, explicit: str | None, label: str):
    """Resolve a single bundle for an app, honoring an explicit override."""
    if explicit:
        root = Path(explicit).expanduser().resolve()
        manifest = root / "manifest.json"
        skills_dir = root / "skills"
        if not (manifest.exists() and skills_dir.is_dir()):
            sys.exit(
                f"ERROR: --{label} path does not look like a skills bundle "
                f"(missing manifest.json or skills/): {root}"
            )
        return {"root": root, "manifest": manifest, "skills_dir": skills_dir,
                "mtime": manifest.stat().st_mtime}

    bundles = discover_bundles(app_name)
    if not bundles:
        sys.exit(
            f"ERROR: no {app_name} skills bundle found under "
            f"{app_support_root() / app_name / 'local-agent-mode-sessions' / 'skills-plugin'}\n"
            f"       Pass --{label} <path-to-bundle> to point at it manually."
        )
    chosen = bundles[0]
    if len(bundles) > 1:
        log(f"NOTE: {len(bundles)} {app_name} bundles found; using the most recently "
            f"modified one:\n      {chosen['root']}")
        log(f"      (override with --{label} if that's wrong)")
    return chosen


def list_skill_dirs(skills_dir: Path):
    """Return the set / list of skill folder names in a skills/ directory."""
    return sorted(
        p.name for p in skills_dir.iterdir()
        if p.is_dir() and not p.name.startswith(".")
    )


# --------------------------------------------------------------------------- #
# Manifest registry handling (schema-adaptive)
# --------------------------------------------------------------------------- #

def find_registry(manifest):
    """Locate the list of skill entries inside a manifest.

    Returns (container_dict, key, list) or None if not found.
    """
    if isinstance(manifest, list):
        # The manifest itself is the list of entries.
        return (None, None, manifest)
    if isinstance(manifest, dict):
        for key in KNOWN_REGISTRY_KEYS:
            val = manifest.get(key)
            if isinstance(val, list):
                return (manifest, key, val)
        # Generic fallback: first top-level list of dicts.
        for key, val in manifest.items():
            if isinstance(val, list) and val and all(isinstance(x, dict) for x in val):
                return (manifest, key, val)
    return None


def entry_identity(entry: dict):
    """Best-effort skill name for a manifest entry."""
    if not isinstance(entry, dict):
        return None
    for k in NAME_KEYS:
        v = entry.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    for k in PATH_KEYS:
        v = entry.get(k)
        if isinstance(v, str) and v.strip():
            return os.path.basename(v.rstrip("/\\"))
    return None


def build_entry_for_skill(skill_name: str, source_registry_list, target_registry_list):
    """Create a manifest entry for a migrated skill.

    Preference order:
      1. Clone the matching entry from the SOURCE manifest (most faithful).
      2. Clone a TEMPLATE entry from the TARGET manifest and rename it.
      3. Emit a minimal {"name": skill_name} entry.
    Any path-like field is rewritten to 'skills/<skill_name>'.
    """
    def rewrite_paths(entry: dict):
        for k in PATH_KEYS:
            if k in entry and isinstance(entry[k], str):
                # Normalize to a relative skills/<name> path.
                entry[k] = f"skills/{skill_name}"
        for k in NAME_KEYS:
            if k in entry and isinstance(entry[k], str):
                entry[k] = skill_name
        return entry

    # 1. Faithful clone from source.
    for e in (source_registry_list or []):
        if entry_identity(e) == skill_name:
            return rewrite_paths(copy.deepcopy(e))

    # 2. Template clone from target.
    if target_registry_list:
        template = copy.deepcopy(target_registry_list[0])
        return rewrite_paths(template)

    # 3. Minimal.
    return {"name": skill_name, "path": f"skills/{skill_name}"}


# --------------------------------------------------------------------------- #
# Migration
# --------------------------------------------------------------------------- #

def migrate(source, target, apply: bool):
    src_skills_dir = source["skills_dir"]
    tgt_skills_dir = target["skills_dir"]

    src_names = list_skill_dirs(src_skills_dir)
    tgt_names = set(list_skill_dirs(tgt_skills_dir))

    to_copy = [n for n in src_names if n not in tgt_names]
    skipped = [n for n in src_names if n in tgt_names]

    log("=" * 68)
    log("Claude  Claude-3p  skill migration")
    log("=" * 68)
    log(f"Source (Claude)    : {source['root']}")
    log(f"Target (Claude-3p) : {target['root']}")
    log("")
    log(f"Skills in source   : {len(src_names)}")
    log(f"Already in target  : {len(skipped)}  -> skipped: {', '.join(skipped) or '(none)'}")
    log(f"To migrate         : {len(to_copy)}  -> {', '.join(to_copy) or '(none)'}")
    log("")

    if not to_copy:
        log("Nothing to migrate. Target already has every source skill. Done.")
        return

    if not apply:
        log("DRY RUN  no changes made. Re-run with --apply to perform the migration.")
        return

    # ---- 1. Copy skill folders ------------------------------------------- #
    copied = []
    for name in to_copy:
        src = src_skills_dir / name
        dst = tgt_skills_dir / name
        try:
            shutil.copytree(src, dst)
            copied.append(name)
            log(f"  copied  {name}")
        except Exception as exc:  # noqa: BLE001  keep going on individual failures
            log(f"  FAILED  {name}: {exc}")

    if not copied:
        log("No folders copied successfully; leaving manifest untouched.")
        return

    # ---- 2. Merge manifest entries (with backup) ------------------------- #
    try:
        src_manifest = load_json(source["manifest"])
    except Exception as exc:  # noqa: BLE001
        src_manifest = None
        log(f"WARNING: could not read source manifest ({exc}); "
            f"entries will be synthesized from a target template.")

    try:
        tgt_manifest = load_json(target["manifest"])
    except Exception as exc:  # noqa: BLE001
        log(f"WARNING: could not read target manifest ({exc}). "
            f"Skill folders were copied, but the manifest was NOT updated.")
        _summary(copied, [])
        return

    src_reg = find_registry(src_manifest) if src_manifest is not None else None
    tgt_reg = find_registry(tgt_manifest)

    if tgt_reg is None:
        log("WARNING: could not locate a skills registry list in the target manifest.")
        log("         Skill folders were copied, but manifest.json was NOT modified.")
        log("         The app may still auto-discover the folders on next launch.")
        _summary(copied, [])
        return

    tgt_container, tgt_key, tgt_list = tgt_reg
    src_list = src_reg[2] if src_reg else []

    existing_ids = {entry_identity(e) for e in tgt_list}
    added = []
    for name in copied:
        if name in existing_ids:
            continue  # already registered
        entry = build_entry_for_skill(name, src_list, tgt_list)
        tgt_list.append(entry)
        added.append(name)

    if added:
        backup = target["manifest"].with_name(
            f"manifest.backup-{_now_stamp()}.json"
        )
        shutil.copy2(target["manifest"], backup)
        dump_json(target["manifest"], tgt_manifest)
        log("")
        log(f"  manifest backed up to: {backup.name}")
        log(f"  manifest updated: added {len(added)} entr"
            f"{'y' if len(added) == 1 else 'ies'} "
            f"under key '{tgt_key or '(top-level list)'}'")
    else:
        log("  manifest already contained entries for all copied skills; not modified.")

    _summary(copied, added)


def _summary(copied, added):
    log("")
    log("-" * 68)
    log(f"Done. {len(copied)} skill folder(s) copied, "
        f"{len(added)} manifest entr{'y' if len(added) == 1 else 'ies'} added.")
    log("Restart the Claude-3p desktop app to pick up the migrated skills.")
    log("-" * 68)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Migrate Claude (1P) skills into Claude-3p. "
                    "Auto-discovers per-user bundles; dry run by default."
    )
    parser.add_argument("--apply", action="store_true",
                        help="Actually perform the migration (default is a dry run).")
    parser.add_argument("--list", action="store_true",
                        help="List discovered source/target bundles and exit.")
    parser.add_argument("--source", metavar="PATH",
                        help="Explicit source bundle root (contains manifest.json + skills/).")
    parser.add_argument("--target", metavar="PATH",
                        help="Explicit target bundle root (contains manifest.json + skills/).")
    args = parser.parse_args(argv)

    if args.list:
        for app in (SOURCE_APP, TARGET_APP):
            log(f"\n{app} bundles:")
            found = discover_bundles(app)
            if not found:
                log("  (none found)")
            for b in found:
                names = list_skill_dirs(b["skills_dir"])
                log(f"  {b['root']}")
                log(f"      {len(names)} skills: {', '.join(names)}")
        return 0

    source = pick_bundle(SOURCE_APP, args.source, "source")
    target = pick_bundle(TARGET_APP, args.target, "target")
    migrate(source, target, apply=args.apply)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
